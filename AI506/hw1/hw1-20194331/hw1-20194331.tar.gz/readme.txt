Reference

1. set data type in python
https://wikidocs.net/1015

2. combinations module
https://medium.com/@hckcksrl/python-permutation-combination-a7bf9e5d6ab3

